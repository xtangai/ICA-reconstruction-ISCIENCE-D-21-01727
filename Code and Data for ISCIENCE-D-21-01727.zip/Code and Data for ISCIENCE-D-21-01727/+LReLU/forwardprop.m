function da = forwardprop(dn,n,a,param)
%PURELIN.FORWARDPROP

% Copyright 2012 The MathWorks, Inc.

% da = bsxfun(@times,dn,(n>=0 + 0.05* (n<0)));

load myfcn
[M,N] = size(n);
tmp = differentiate (myfcn,n);
tmp = reshape(tmp,[M,N]);
da = bsxfun(@times,dn,tmp);