function [val,pos] = FindPeak(x)
L = 300;
N1 = length(x);

val = [];
pos = [];
for i = (L+1):(N1-L)
   if x(i)>max(x(i-L:i-1)) & x(i)>max(x(i+1:i+L))
      val = [val;x(i)];
      pos = [pos;i];
   end
end


