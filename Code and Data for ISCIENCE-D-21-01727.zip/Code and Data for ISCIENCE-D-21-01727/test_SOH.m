clc
clear all
load C

for j = 1:4
    volt_ref(j).dat = C(j).volt_ref;
    curr_ref(j).dat = C(j).curr_ref;
    time_ref(j).dat = (1:length(volt_ref(j).dat))';
end

for bat = 1:4
    NI = 1200;
    f1 = FitSM(time_ref(bat).dat, volt_ref(bat).dat);
    tmp = time_ref(bat).dat;
    volt_sm(bat).dat = f1(tmp);
    for j = NI:length(volt_ref(bat).dat)
        ica_ref(bat).dat(j) = sum(0.5*NI)/3600/ (volt_sm(bat).dat(j) - volt_sm(bat).dat(j-NI+1));
    end
end

for bat = 1:4
    [val pos] = FindPeak(ica_ref(bat).dat);
    Ref_val = val';
    Ref_pos = volt_ref(bat).dat(pos)';
    V_LM = Ref_pos(2) ;
    V_UP = Ref_pos(3) ;
    Dif_train (bat) = length(find(volt_ref(bat).dat>V_LM & volt_ref(bat).dat<V_UP ))
end

clear ica_ref
 
load ica_this
Imean = 1.53;


for bat = 1:6
    [val pos] = FindPeak(ica_this(bat).dat);
    Ref_val = val';
    Ref_pos = volt_this(bat).dat(pos)';
    V_LM = Ref_pos(2) ;
    V_UP = Ref_pos(3) ;
    Dif_test (bat) = length(find(volt_this(bat).dat>V_LM & volt_this(bat).dat<V_UP ))
end

SoH_train = [96.1;93.7;88.5;87.1];
fD = LinFit(Dif_train,SoH_train);
SoH_test = [86.9867;91.4000;91.6400;99.3333;98.4267;96.2000];


z = figure;
str = 'ABCDEFG'
set(z,'units','centimeters','Position',[2,2,22,20]);
subplot(2,2,1)
b = bar([SoH_test,fD(Dif_test)],'BarWidth',1);
b(1).FaceColor = [0.0,0.0,0.5];
b(2).FaceColor = [1,1,0];
xlabel('Group No.','interpreter','tex','FontName','Arial');
ylabel('SoH (%)','interpreter','tex','FontName','Arial');
xlim([0.5,6.5]);
ylim([80,100]);
h = legend('Ref','Proposed')
set(h,'Interpreter','tex','FontSize',16,'ItemTokenSize',[15,36],'location','northwest','FontName','Arial');
% h = text(0.02,0.06,'(a)','FontSize',16,'Interpreter','tex','units','normalized');
set(gca,'fontsize',16);
set(gca,'linewidth',2);
set(gca,'TickLabelInterpreter','tex','FontName','Arial');
grid on
box on
text(-0.22,1,str(1),'Fontsize',16,'FontName','Arial','units','normalized');

subplot(2,2,2)
b = bar( fD(Dif_test) - SoH_test,'BarWidth',0.5);
b(1).FaceColor = [0.0,0.0,0.5];
xlabel('Group No.','interpreter','tex','FontName','Arial');
ylabel('SoH error (%)','interpreter','tex','FontName','Arial');
xlim([0.5,6.5]);
ylim([-0.3,1]);
set(gca,'YTick',[-0.2:0.2:1.0]);
h = legend('Error')
set(h,'Interpreter','tex','FontSize',16,'ItemTokenSize',[15,36],'FontName','Arial');
% h = text(0.02,0.06,'(b)','FontSize',16,'Interpreter','tex','units','normalized');
set(gca,'fontsize',16);
set(gca,'linewidth',2);
set(gca,'TickLabelInterpreter','tex','FontName','Arial');
grid on
box on
text(-0.22,1,str(2),'Fontsize',16,'FontName','Arial','units','normalized');