function [fitresult, gof] = LinFit(Val_train, SoH_train)
%CREATEFIT(VAL_TRAIN,SOH_TRAIN)
%  Create a fit.
%
%  Data for 'untitled fit 1' fit:
%      X Input : Val_train
%      Y Output: SoH_train
%  Output:
%      fitresult : a fit object representing the fit.
%      gof : structure with goodness-of fit info.
%
%  ������� FIT, CFIT, SFIT.

%  �� MATLAB �� 18-May-2021 03:44:31 �Զ�����


%% Fit: 'untitled fit 1'.
[xData, yData] = prepareCurveData( Val_train, SoH_train );

% Set up fittype and options.
ft = fittype( 'poly1' );
opts = fitoptions( 'Method', 'LinearLeastSquares' );
opts.Robust = 'LAR';

% Fit model to data.
[fitresult, gof] = fit( xData, yData, ft );

