%% test all
clc
clear all

load myfcn
load net_base
load CLT

for j = 1:4
    I(j).dat = C(j).curr_test;
    V(j).dat = C(j).volt_test;
    
    Ism(j).dat = smooth(I(j).dat,60);
    Vsm(j).dat = smooth(V(j).dat,60);
    
    volt_ref(j).dat = C(j).volt_ref;
    curr_ref(j).dat = C(j).curr_ref;
    time_ref(j).dat = (1:length(volt_ref(j).dat))';
    time_test(j).dat = (1:length(V(j).dat))';
end


% mean current of the CC charging
Imean = 0.500;
for bat = 1:4
    j = 1;
    ind(bat) = 1;
    time_new(bat).dat(ind(bat)) = 1;
    volt_new(bat).dat(ind(bat)) = C(bat).volt_test(1);
    ica_ref(bat).dat(j) = 0;
    ica_this(bat).dat(j)= 0;
    ica_ini(bat).dat(j) = 0;
end

for bat = 1:4
    L_last(bat) = 1;
    for L = 1:length(Ism(bat).dat)
        if abs(Ism(bat).dat(L) - Imean)<0.005
            ind(bat) = ind(bat)+1;
            time_new(bat).dat(ind(bat)) = L*mean(I(bat).dat(1:L))/Imean;
            volt_new(bat).dat(ind(bat)) = Vsm(bat).dat(L);
        end
    end
end

% figure
% hold on
% plot(I(1).dat,'linestyle','-.','linewidth',0.5,'marker','o')
% plot(Ism(1).dat,'linewidth',2)
% plot(time_ref(1).dat,curr_ref(1).dat,'linestyle','-.','marker','.')
% xlabel('Time (s)');
% ylabel('Current (A)');
% legend('Actual','Smoothed','Designed')
% 
% 
% figure
% hold on
% plot(time_test(1).dat,V(1).dat,'linestyle','-.','marker','.','markersize',6)
% plot(time_new(1).dat,volt_new(1).dat,'linestyle','-.','marker','.','markersize',6)
% plot(time_ref(1).dat,volt_ref(1).dat,'linewidth',2)
% xlabel('Time (s)');
% ylabel('Voltage (V)');
% legend('Referenced','Re-constrcuted')





for bat = 2:4
    net_base.trainFcn = 'trainlm';
    net_base.trainParam.epochs = 150;
    net(bat).dat = net_base;
end
for bat = 2:4
    net(bat).dat = train(net(bat).dat,time_new(bat).dat,volt_new(bat).dat);
end
for bat = 2:4
    N1 = length(V(bat).dat);
    volt_this(bat).dat = sim(net(bat).dat,1:N1);
    NI = 1200;
    f1 = FitSM(time_ref(bat).dat, volt_ref(bat).dat);
    tmp = time_ref(bat).dat;
    volt_sm(bat).dat = f1(tmp);
    for j = NI:length(volt_ref(bat).dat)
        ica_ref(bat).dat(j) = sum(0.5*NI)/3600/ (volt_sm(bat).dat(j) - volt_sm(bat).dat(j-NI+1));
    end
    
    for j = NI:length(volt_this(bat).dat)
        ica_this(bat).dat(j)= sum(0.5*NI)/3600/ (volt_this(bat).dat(j) - volt_this(bat).dat(j-NI+1));
    end
    
    for j = NI:length(V(bat).dat)
        ica_ini(bat).dat(j) = sum(I(bat).dat(j-NI+1:j))/3600/ (V(bat).dat(j) - V(bat).dat(j-NI+1));
    end
end

% z = figure;
% set(z,'units','centimeters','Position',[2,2,22,20]);
%
% subplot(2,2,1)
% hold on
% plot(time_ref(1).dat/60,volt_ref(1).dat,'linewidth',2)
% plot(time_ref(2).dat/60,volt_ref(2).dat,'linewidth',2)
% plot(time_ref(3).dat/60,volt_ref(3).dat,'linewidth',2)
% plot(time_ref(4).dat/60,volt_ref(4).dat,'linewidth',2)
%
% xlabel('Time (s)','interpreter','tex');
% ylabel('Voltage (V)','interpreter','tex');
% h = legend('#01','#02','#03','#04');
% set(h,'Interpreter','tex','FontSize',16,'ItemTokenSize',[15,36],'location','east');
% set(gca,'fontsize',16);
% set(gca,'linewidth',2);
% set(gca,'YLim',[3,4.22]);
% yticks(3:0.2:4.2)
% set(gca,'TickLabelInterpreter','tex');
% h = text(0.02,0.06,'(a): Voltage trajectories','FontSize',16,'Interpreter','tex','units','normalized');
% grid on
% box on
%
% str = 'abcd';
% for bat = 2:4
%     subplot(2,2,bat)
%     hold on
%     lab = find(ica_ini(bat).dat>0);
%     plot(Vsm(bat).dat(lab),ica_ini(bat).dat(lab),'linewidth',0.5,'marker','.')
%     lab = find(ica_ref(bat).dat>0);
%     plot(volt_sm(bat).dat(lab), ica_ref(bat).dat(lab),'linewidth',2);
%     lab = find(ica_this(bat).dat>0);
%     plot(volt_this(bat).dat(lab), ica_this(bat).dat(lab),'linestyle','-.','linewidth',2);
%     set(gca,'YLim',[0,5.5]);
%     yticks(0:1:5)
%     set(gca,'XLim',[3.4,4.22]);
%     xlabel('Voltage (V)','interpreter','tex');
%     ylabel('$\Delta Q/\Delta V$ (Ah/V)','interpreter','tex');
%     set(gca,'fontsize',16);
%     set(gca,'linewidth',2);
%     set(gca,'TickLabelInterpreter','tex');
%     h = text(0.02,0.06,['(',str(bat),'): Cell #0',num2str(bat)],'FontSize',16,'Interpreter','tex','units','normalized');
%     grid on
%     box on
%
%     if bat == 4
%         h = legend('Benchmark','Referenced','Proposed')
%         set(h,'Interpreter','tex','FontSize',16,'ItemTokenSize',[15,36],'location','northeast');
%     end
% end

z = figure;
set(z,'units','centimeters','Position',[2,2,33,20]);


str = 'ABCDEFG'
for bat = 2:4
    subplot(2,3,bat-1)
    hold on
    plot(time_test(bat).dat/60,V(bat).dat,'linewidth',2)
    plot(time_ref(bat).dat/60,volt_ref(bat).dat,'linewidth',2)
    plot(time_new(bat).dat/60,volt_new(bat).dat,'linewidth',2)
    xlabel('Time (min)','interpreter','tex','FontName','Arial');
    %     if bat == 2
    ylabel('Voltage (V)','interpreter','tex','FontName','Arial');
    %     end
    set(gca,'XLim',[0,330]);
    set(gca,'YLim',[3.05,4.22]);
    set(gca,'xtick',[0:80:330]);
    set(gca,'ytick',[3:0.2:4.2]);
    
    
    
    
    %     yyaxis right
    %     hold on
    %     plot(time_test(bat).dat/60,I(bat).dat,'linewidth',0.5,'color',[0.4940    0.1840    0.5560])
    %     plot(time_ref(bat).dat/60,curr_ref(bat).dat,'linestyle','-','linewidth',2,'color',[0.4660    0.6740    0.1880])
    %     if bat ==4
    %     ylabel('Current (A)','interpreter','tex');
    %     end
    %     set(gca,'YLim',[0,0.7]);
    %     set(gca,'XLim',[0,280]);
    %     set(gca,'xtick',[0:50:250]);
    %     set(gca,'ytick',[0:0.1:0.7]);
    set(gca,'fontsize',16);
    set(gca,'linewidth',2);
    set(gca,'TickLabelInterpreter','tex','FontName','Arial');
    grid on
    box on
    h = text(0.15,0.06,['Voltage of Cell #0',num2str(bat)],'FontSize',16,'Interpreter','tex','units','normalized','FontName','Arial');
    if bat == 4
        h = legend('Measured','Referenced','{S}elected')
        set(h,'Interpreter','tex','FontSize',16,'ItemTokenSize',[15,36],'Position',[0.79 0.64 0.10 0.10],'FontName','Arial');
    end
    
    text(-0.22,1,str(bat-1),'Fontsize',16,'FontName','Arial','units','normalized');
    
    if bat == 2
        axes1 = axes('Position',[0.265 0.665 0.07 0.11]);
        hold on
        plot(time_test(bat).dat/60,V(bat).dat,'linewidth',2)
        plot(time_ref(bat).dat/60,volt_ref(bat).dat,'linewidth',2)
        plot(time_new(bat).dat/60,volt_new(bat).dat,'linewidth',2)
        set(gca,'fontsize',12);
        set(gca,'linewidth',1);
        set(gca,'TickLabelInterpreter','tex','FontName','Arial');
        
        set(gca,'XLim',[190,194]);
        set(gca,'xtick',[190:2:194]);
        set(gca,'YLim',[3.82,3.99]);
        set(gca,'ytick',[3.8:0.05:4]);
        grid on
        box on
    end
    
    if bat == 3
        axes2 = axes('Position',[0.545 0.665 0.07 0.11]);
        hold on
        plot(time_test(bat).dat/60,V(bat).dat,'linewidth',2)
        plot(time_ref(bat).dat/60,volt_ref(bat).dat,'linewidth',2)
        plot(time_new(bat).dat/60,volt_new(bat).dat,'linewidth',2)
        set(gca,'fontsize',12);
        set(gca,'linewidth',1);
        set(gca,'TickLabelInterpreter','tex','FontName','Arial');
        set(gca,'XLim',[190,194]);
        set(gca,'xtick',[190:2:194]);
        set(gca,'YLim',[4.10,4.13]);
        set(gca,'ytick',[3.93:0.01:4.2]);
        grid on
        box on
    end
    
    
    
    subplot(2,3,bat+2)
    hold on
    lab = find(ica_ini(bat).dat>0);
    plot(Vsm(bat).dat(lab),ica_ini(bat).dat(lab),'linestyle',':','linewidth',0.5,'marker','.')
    lab = find(ica_ref(bat).dat>0);
    plot(volt_sm(bat).dat(lab), ica_ref(bat).dat(lab),'linewidth',2);
    lab = find(ica_this(bat).dat>0 & ica_this(bat).dat <4.5);
    plot(volt_this(bat).dat(lab), ica_this(bat).dat(lab),'linestyle','-.','linewidth',2);
    set(gca,'YLim',[0,5.5]);
    set(gca,'YTick',[0:1:8]);
    set(gca,'XLim',[3.5,4.22]);
    xlabel('Voltage (V)','interpreter','tex','FontName','Arial');
    ylabel('\DeltaQ/\DeltaV (Ah/V)','interpreter','tex','FontName','Arial');
    set(gca,'fontsize',16);
    set(gca,'linewidth',2);
    set(gca,'TickLabelInterpreter','tex');
    h = text(0.12,0.06,['IC trajectories of #0',num2str(bat)],'FontSize',16,'Interpreter','tex','units','normalized','FontName','Arial');
    grid on
    box on
    
    if bat == 4
        h = legend('Raw','Referenced','Proposed')
        set(h,'Interpreter','tex','FontSize',16,'ItemTokenSize',[15,36],'location','northeast','FontName','Arial');
    end
    
    text(-0.22,1,str(bat+2),'Fontsize',16,'FontName','Arial','units','normalized');
    
    
end


% 创建 arrow
annotation('arrow',[0.259566498316498 0.281481481481481],...
    [0.802993055555555 0.778416666666667],'LineWidth',1);

% 创建 rectangle
annotation('rectangle',...
    [0.251202565473009 0.803583223104056 0.00569137392093033 0.0596944444444446],...
    'LineWidth',1);

% 创建 rectangle
annotation('rectangle',...
    [0.532335878831068 0.888013668430336 0.00569137392093022 0.0114638447971779],...
    'LineWidth',1);

% 创建 arrow
annotation('arrow',[0.539650673400673 0.575628006413683],...
    [0.88425 0.783068783068783],'LineWidth',1);




for bat = 2:4
    [val pos] = FindPeak(ica_ref(bat).dat);
    Ref_val = val';
    Ref_pos = volt_ref(bat).dat(pos)';
    [val pos] = FindPeak(ica_this(bat).dat);
    This_val = val';
    This_pos = volt_this(bat).dat(pos);
    err_val = (Ref_val(1:3) - This_val(1:3))./Ref_val(1:3)*100
    err_pos = (Ref_pos(1:3) - This_pos(1:3))./Ref_pos(1:3)*100
end



