%% plot single bat config
%% illustration data selection.
clc
clear all

load C

for j = 1:4
    I(j).dat = C(j).curr_ref + randn(length(C(j).curr_ref),1)*0.01;
    V(j).dat = C(j).volt_ref + randn(length(C(j).volt_ref),1)*0.01;
    
    Ism(j).dat = smooth(I(j).dat,60);
    Vsm(j).dat = smooth(V(j).dat,60);
    
    volt_ref(j).dat = C(j).volt_ref;
    curr_ref(j).dat = C(j).curr_ref;
    time_ref(j).dat = (1:length(volt_ref(j).dat))';
end


for bat = 1:4
    NI = 1200;
    f1 = FitSM(time_ref(bat).dat, volt_ref(bat).dat);
    tmp = time_ref(bat).dat;
    volt_sm(bat).dat = f1(tmp);
    for j = NI:length(volt_ref(bat).dat)
        ica_ref(bat).dat(j) = sum(curr_ref(bat).dat((j-NI+1):j))/3600/ (volt_sm(bat).dat(j) - volt_sm(bat).dat(j-NI+1));
    end
end





z = figure;
set(z,'units','centimeters','Position',[2,2,22,20]);

subplot(2,2,1)
hold on
plot(time_ref(1).dat/60,volt_ref(1).dat,'linewidth',2)
plot(time_ref(2).dat/60,volt_ref(2).dat,'linewidth',2)
plot(time_ref(3).dat/60,volt_ref(3).dat,'linewidth',2)
plot(time_ref(4).dat/60,volt_ref(4).dat,'linewidth',2)

xlabel('Time (s)','interpreter','latex');
ylabel('Voltage (V)','interpreter','latex');
% h = legend('\#01','\#02','\#03','\#04');
% set(h,'Interpreter','latex','FontSize',16,'ItemTokenSize',[15,36],'location','east');
set(gca,'fontsize',16);
set(gca,'linewidth',2);
set(gca,'YLim',[3,4.22]);
set(gca,'YTick',[3:0.2:4.2]);
set(gca,'TickLabelInterpreter','latex');
h = text(0.02,0.06,'(a): Voltage trajectories','FontSize',16,'Interpreter','latex','units','normalized');
grid on
box on

subplot(2,2,2)
hold on
for bat = 1:4
    lab = find(ica_ref(bat).dat>0);
    plot(volt_sm(bat).dat(lab), ica_ref(bat).dat(lab),'linewidth',2);
end

xlabel('Voltage (V)','interpreter','latex');
ylabel('$\Delta Q/\Delta V$ (Ah/V)','interpreter','latex');
h = legend('\#01','\#02','\#03','\#04');
set(h,'Interpreter','latex','FontSize',16,'ItemTokenSize',[15,36],'location','northeast');
set(gca,'fontsize',16);
set(gca,'linewidth',2);
set(gca,'XLim',[3.4,4.22]);
set(gca,'YLim',[0,5.5]);
set(gca,'YTick',[0:1:5]);
set(gca,'TickLabelInterpreter','latex');
h = text(0.02,0.06,'(b): IC trajectories','FontSize',16,'Interpreter','latex','units','normalized');
grid on
box on


