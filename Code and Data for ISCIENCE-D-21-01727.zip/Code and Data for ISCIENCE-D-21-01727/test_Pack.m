%% test all
clc
clear all

load myfcn
load net_base
% load data without balancing to calculate the reference value
load Pack_ic_ref


for j = 1:6
    N1 = length(Ref(j).volt);
    time_ref(j).dat = 1:N1;
    volt_ref(j).dat = Ref(j).volt;
    curr_ref(j).dat = Ref(j).curr;
end

load Pur_BCR

for j = 1:6
    I(j).dat = PackI + Ibal(j).dat;
    Ism(j).dat = smooth(I(j).dat,60);
    Vsm(j).dat = smooth(V(j).dat,60);
    time_test(j).dat = 1:length(Vsm(j).dat);
end

% mean current of the CC charging
Imean = 1.53;
for bat = 1:6
    j = 1;
    ind(bat) = 1;
    time_new(bat).dat(ind(bat)) = 1;
    volt_new(bat).dat(ind(bat)) = Vsm(bat).dat(1);
    ica_ref(bat).dat(j) = 0;
    ica_this(bat).dat(j)= 0;
    ica_ini(bat).dat(j) = 0;
end

for bat = 1:6
    L_last(bat) = 1;
    for L = 1:length(Ism(bat).dat)
        if abs(Ism(bat).dat(L) - Imean)<0.005
            ind(bat) = ind(bat)+1;
            time_new(bat).dat(ind(bat)) = L*mean(I(bat).dat(1:L))/Imean;
            volt_new(bat).dat(ind(bat)) = Vsm(bat).dat(L);
        end
    end
end


% figure
% hold on
% plot(I(1).dat,'linestyle','-.','linewidth',0.5,'marker','o')
% plot(Ism(1).dat,'linewidth',2)
% plot(time_ref(1).dat,curr_ref(1).dat,'linestyle','-.','marker','.')
% xlabel('Time (s)');
% ylabel('Current (A)');
% legend('Actual','Smoothed','Designed')
% 
% 
% figure
% hold on
% plot(time_test(1).dat,V(1).dat,'linestyle','-.','marker','.','markersize',6)
% plot(time_new(1).dat,volt_new(1).dat,'linestyle','-.','marker','.','markersize',6)
% plot(time_ref(1).dat,volt_ref(1).dat,'linewidth',2)
% xlabel('Time (s)');
% ylabel('Voltage (V)');
% legend('Referenced','Re-constrcuted')





for bat = 1:6
    net_base.trainFcn = 'trainlm';
    net_base.trainParam.epochs = 300;
    net(bat).dat = net_base;
end
parfor bat = 1:6
    net(bat).dat = train(net(bat).dat,time_new(bat).dat,volt_new(bat).dat);
end
for bat = 1:6
    N1 = length(V(bat).dat);
    volt_this(bat).dat = sim(net(bat).dat,1:N1);
    NI = 1200;
    f1 = FitSM(time_ref(bat).dat, volt_ref(bat).dat);
    tmp = time_ref(bat).dat;
    volt_sm(bat).dat = f1(tmp);
    for j = NI:length(volt_ref(bat).dat)
        ica_ref(bat).dat(j) = sum(Imean*NI)/3600/ (volt_sm(bat).dat(j) - volt_sm(bat).dat(j-NI+1));
    end
    
    for j = NI:length(volt_this(bat).dat)
        ica_this(bat).dat(j)= sum(Imean*NI)/3600/ (volt_this(bat).dat(j) - volt_this(bat).dat(j-NI+1));
    end
    
    for j = NI:length(V(bat).dat)
        ica_ini(bat).dat(j) = sum(I(bat).dat(j-NI+1:j))/3600/ (V(bat).dat(j) - V(bat).dat(j-NI+1));
    end
end


z = figure;
set(z,'units','centimeters','Position',[2,2,33,20]);


str = 'abcdef';
for bat = 1:6
    subplot(2,3,bat)
    hold on
    plot(time_test(bat).dat/60,I(bat).dat,'linestyle',':','linewidth',0.25,'marker','.','markersize',12)
    plot(time_ref(bat).dat/60,curr_ref(bat).dat,'linewidth',2)
    set(gca,'YLim',[-1.5,2]);
    set(gca,'YTick',[-2:2]);
    set(gca,'XLim',[0,300]);
    xlabel('Time (min)','interpreter','latex');
    ylabel('Current (A)','interpreter','latex');
    set(gca,'fontsize',16);
    set(gca,'linewidth',2);
    set(gca,'TickLabelInterpreter','latex');
    h = text(0.02,0.06,['(',str(bat),'): Current of G0',num2str(bat)],'FontSize',16,'Interpreter','latex','units','normalized');
    grid on
    box on
    
    if bat == 5
        h = legend('Actual','Designed')
        set(h,'Interpreter','latex','FontSize',16,'ItemTokenSize',[15,36],'location','best');
    end
end



z = figure;
set(z,'units','centimeters','Position',[2,2,33,20]);


str = 'abcdef';
for bat = 1:6
    subplot(2,3,bat)
    hold on
    lab = find(ica_ini(bat).dat>0);
    plot(V(bat).dat(lab),ica_ini(bat).dat(lab),'linestyle',':','linewidth',0.25,'marker','.')
    lab = find(ica_ref(bat).dat>0);
    plot(volt_sm(bat).dat(lab), ica_ref(bat).dat(lab),'linewidth',2);
    lab = find(ica_this(bat).dat>0);
    plot(volt_this(bat).dat(lab), ica_this(bat).dat(lab),'linestyle','-.','linewidth',2);
    set(gca,'YLim',[0,18]);
    set(gca,'YTick',[0:3:18]);
    set(gca,'XLim',[3.4,4.22]);
    xlabel('Voltage (V)','interpreter','latex');
    ylabel('$\Delta Q/\Delta V$ (Ah/V)','interpreter','latex');
    set(gca,'fontsize',16);
    set(gca,'linewidth',2);
    set(gca,'TickLabelInterpreter','latex');
    h = text(0.02,0.06,['(',str(bat),'): IC trajectories of G0',num2str(bat)],'FontSize',16,'Interpreter','latex','units','normalized');
    grid on
    box on
    
    if bat == 6
        h = legend('Raw','Referenced','Proposed')
        set(h,'Interpreter','latex','FontSize',16,'ItemTokenSize',[15,36],'location','northeast');
    end
end

for bat = 1:6
    [val pos] = FindPeak(ica_ref(bat).dat);
    Ref_val = val';
    Ref_pos = volt_ref(bat).dat(pos);
    [val pos] = FindPeak(ica_this(bat).dat);
    This_val = val';
    This_pos = volt_this(bat).dat(pos);
    
    if length(This_pos) == 3
        This_pos(4) = 0;
        This_val(4) = 0;
    end
    
    err_val = (Ref_val(1:4) - This_val(1:4))./Ref_val*100
    err_pos = (Ref_pos(1:4) - This_pos(1:4))./Ref_pos*100
end

save ica_this ica_this volt_this