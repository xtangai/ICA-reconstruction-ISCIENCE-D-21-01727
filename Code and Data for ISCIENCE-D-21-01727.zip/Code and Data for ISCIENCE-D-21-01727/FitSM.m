function [fitresult, gof] = FitSM(time, volt)
%CREATEFIT(TIME,VOLT)
%  Create a fit.
%
%  Data for 'untitled fit 1' fit:
%      X Input : time
%      Y Output: volt
%  Output:
%      fitresult : a fit object representing the fit.
%      gof : structure with goodness-of fit info.
%
%  另请参阅 FIT, CFIT, SFIT.

%  �?MATLAB �?18-Mar-2021 14:47:36 自动生成


%% Fit: 'untitled fit 1'.
[xData, yData] = prepareCurveData( time, volt );

% Set up fittype and options.
ft = fittype( 'smoothingspline' );
opts = fitoptions( 'Method', 'SmoothingSpline' );
opts.SmoothingParam = 1e-6;

% Fit model to data.
[fitresult, gof] = fit( xData, yData, ft, opts );



