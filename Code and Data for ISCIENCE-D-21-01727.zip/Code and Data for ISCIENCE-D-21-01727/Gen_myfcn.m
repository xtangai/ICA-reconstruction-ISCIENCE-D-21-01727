clc
clear all

load C

volt_ot = C(1).volt_ref;
time_in = 1:length(volt_ot);

volt_ot = volt_ot(:)';
time_in = time_in(:)';

myfcn = FitSM(time_in, volt_ot);

save myfcn myfcn

net = feedforwardnet([20 20 20]);

net.layers{1}.transferFcn = 'GauLU';
net.layers{2}.transferFcn = 'GauLU';
net.layers{3}.transferFcn = 'myFcn';


net.divideParam.trainRatio = 0.7;
net.divideParam.valRatio = 0.3;
net.divideParam.testRatio = 0.0;
net.trainFcn = 'trainlm';
net = train(net,time_in,volt_ot);
net.trainFcn = 'trainbr';
net = train(net,time_in,volt_ot);
net_base = net;

plot(volt_ot);
hold on 
plot(sim(net,time_in))
save net_base net_base


ot1 = sim(net,time_in);

figure
plot (1./(volt_ot(1201:end) - volt_ot(1:end-1200)))
hold on 
plot (1./(ot1(1201:end) - ot1(1:end-1200)))