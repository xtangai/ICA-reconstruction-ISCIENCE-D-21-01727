function d = da_dn(n,a,param)

% Copyright 2012 The MathWorks, Inc.

% d = double(n >= 0) + double(n<0) * 0.05;

load myfcn
[M,N] = size(n);
tmp = differentiate (myfcn,n);
tmp = reshape(tmp,[M,N]);

d = tmp;