function a = apply(n,param)
%PURELIN.APPLY

% Copyright 2012 The MathWorks, Inc.

load myfcn
[M,N] = size(n);
a = myfcn(n);
a = reshape(a,[M,N]);
% a = max(0,n) + min(0,n) * 0.05;
a(isnan(n)) = nan;
