%% test all
clc
clear all

load myfcn
load net_base
load C

for j = 1:4
    I(j).dat = C(j).curr_ref + randn(length(C(j).curr_ref),1)*0.004;
    V(j).dat = C(j).volt_ref + randn(length(C(j).volt_ref),1)*0.004;
    
    Ism(j).dat = smooth(I(j).dat,60);
    Vsm(j).dat = smooth(V(j).dat,60);
    
    volt_ref(j).dat = C(j).volt_ref;
    curr_ref(j).dat = C(j).curr_ref;
    time_ref(j).dat = (1:length(volt_ref(j).dat))';
end


% mean current of the CC charging
Imean = 0.500;
for bat = 1:4
    j = 1;
    ind(bat) = 1;
    time_new(bat).dat(ind(bat)) = 1;
    volt_new(bat).dat(ind(bat)) = C(bat).volt_test(1);
    ica_ref(bat).dat(j) = 0;
    ica_this(bat).dat(j)= 0;
    ica_ini(bat).dat(j) = 0;
end

for bat = 1:4
    L_last(bat) = 1;
    for L = 1:length(Ism(bat).dat)
        if abs(Ism(bat).dat(L) - Imean)<0.005
            ind(bat) = ind(bat)+1;
            time_new(bat).dat(ind(bat)) = L*mean(I(bat).dat(1:L))/Imean;
            volt_new(bat).dat(ind(bat)) = Vsm(bat).dat(L);
        end
    end
end
% 
% figure
% hold on
% plot(I(1).dat,'linestyle','-.','linewidth',0.5,'marker','o')
% plot(Ism(1).dat,'linewidth',2)
% plot(time_ref(1).dat,curr_ref(1).dat,'linestyle','-.','marker','.')
% xlabel('Time (s)');
% ylabel('Current (A)');
% legend('Actual','Smoothed','Designed')
% 
% 
% figure
% hold on
% plot(time_ref(1).dat,V(1).dat,'linestyle','-.','marker','.','markersize',6)
% plot(time_new(1).dat,volt_new(1).dat,'linestyle','-.','marker','.','markersize',6)
% plot(time_ref(1).dat,volt_ref(1).dat,'linewidth',2)
% xlabel('Time (s)');
% ylabel('Voltage (V)');
% legend('Referenced','Re-constrcuted')





for bat = 1:4
    net_base.trainFcn = 'trainbr';
    net_base.trainParam.epochs = 50;
    net(bat).dat = net_base;
end
for bat = 1:4
    net(bat).dat = train(net(bat).dat,time_new(bat).dat,volt_new(bat).dat);
end
for bat = 1:4
    N1 = length(V(bat).dat);
    volt_this(bat).dat = sim(net(bat).dat,1:N1);
    NI = 1200;
    f1 = FitSM(time_ref(bat).dat, volt_ref(bat).dat);
    tmp = time_ref(bat).dat;
    volt_sm(bat).dat = f1(tmp);
    for j = NI:length(volt_ref(bat).dat)
        ica_ref(bat).dat(j) = sum(curr_ref(bat).dat((j-NI+1):j))/3600/ (volt_sm(bat).dat(j) - volt_sm(bat).dat(j-NI+1));
    end
    
    for j = NI:length(volt_this(bat).dat)
        ica_this(bat).dat(j)= sum(I(bat).dat((j-NI+1):j))/3600/ (volt_this(bat).dat(j) - volt_this(bat).dat(j-NI+1));
    end
    
    for j = NI:length(V(bat).dat)
        ica_ini(bat).dat(j) = sum(I(bat).dat(j-NI+1:j))/3600/ (V(bat).dat(j) - V(bat).dat(j-NI+1));
    end
end

z = figure;
set(z,'units','centimeters','Position',[2,2,33,20]);

str = 'ABCDEFG'

    

for bat = 2:4
    subplot(2,3,bat-1)
    hold on
    h1 = plot(time_ref(bat).dat/60,V(bat).dat,'linewidth',2)
    h2 = plot(time_ref(bat).dat/60,volt_ref(bat).dat,'linewidth',2)
    xlabel('Time (min)','interpreter','tex','FontName','Arial');
    if bat == 2
        ylabel('Voltage (V)','interpreter','tex','FontName','Arial');
    end
    set(gca,'XLim',[0,280]);
    set(gca,'YLim',[3.20,4.22]);
    set(gca,'xtick',[0:60:250]);
    set(gca,'ytick',[3:0.2:4.2]);
    set(gca,'fontsize',16);
    set(gca,'linewidth',2);
    set(gca,'TickLabelInterpreter','tex');
    set(gca,'FontName','Arial');
        grid on
        box on
    
    
    ax1 = gca;
    ax1.XColor = 'none';
    ax1_pos = ax1.Position; % position of first axes
    
    if bat == 2
        axes4 = axes('Position',[0.26 0.63 0.07 0.12]);
        hold(axes4,'on');
        h1 = plot(time_ref(bat).dat/60,V(bat).dat,'linewidth',2)
        h2 = plot(time_ref(bat).dat/60,volt_ref(bat).dat,'linewidth',2)
        set(gca,'XLim',[7,25]);
        set(gca,'YLim',[3.35,3.45]);
        set(gca,'xtick',[8:8:24]);
        %     set(gca,'ytick',[3:0.2:4.2]);
        set(gca,'fontsize',12);
        set(gca,'linewidth',1.0);
        set(gca,'TickLabelInterpreter','tex');
        set(gca,'FontName','Arial');
        box on
        grid on
        set(gcf,'color','white')
        set(gca,'color','white')
    end
    
    
    ax2 = axes('Position',ax1_pos,...
        'XAxisLocation','bottom',...
        'YAxisLocation','right',...
        'Color','none');
    %     yyaxis right
%     ax2.YColor = 'b';
    
    hold on
    h3 = plot(time_ref(bat).dat/60,I(bat).dat,'linewidth',2,'color',[0.4940    0.1840    0.5560])
    h4 = plot(time_ref(bat).dat/60,0.5*ones(length(time_ref(bat).dat),1),'linestyle','-','linewidth',2,'color',[0.4660    0.6740    0.1880])
    if bat ==4
        ylabel('Current (A)','interpreter','tex','FontName','Arial');
    end
    xlabel('Time (min)','interpreter','tex','FontName','Arial');
    set(gca,'YLim',[0.1,0.61]);
    set(gca,'XLim',[0,280]);
    set(gca,'xtick',[0:60:250]);
    set(gca,'ytick',[0.0:0.1:0.6]);
    set(gca,'fontsize',16);
    set(gca,'linewidth',2);
    set(gca,'TickLabelInterpreter','tex');
    
    if bat ~=4
        h = text(0.02,0.06,[' Cell #0',num2str(bat)],'FontSize',16,'Interpreter','tex','units','normalized','FontName','Arial');
    end
    if bat == 4
        h = text(0.02,0.06,[' Cell #0',num2str(bat)],'FontSize',16,'Interpreter','tex','units','normalized','FontName','Arial');
        
        h = legend([h1,h2,h3,h4],'Voltage: noisy','Voltage: ref','Current: noisy','Current: ref','Color','w')
        set(h,'Interpreter','tex','FontSize',16,'ItemTokenSize',[15,36],'location','best','FontName','Arial');
    end
    %
    if bat < 4
        yticklabels({'','','','','',''})
    end
    
    text(-0.22,1,str(bat-1),'Fontsize',16,'FontName','Arial','units','normalized');
    
%     grid on
    box on
    
    subplot(2,3,bat+2)
    hold on
    lab = find(ica_ini(bat).dat>0);
    plot(V(bat).dat(lab),ica_ini(bat).dat(lab),'linestyle','--','linewidth',0.5,'marker','.')
    lab = find(ica_ref(bat).dat>0);
    plot(volt_sm(bat).dat(lab), ica_ref(bat).dat(lab),'linewidth',2);
    lab = find(ica_this(bat).dat>0);
    plot(volt_this(bat).dat(lab), ica_this(bat).dat(lab),'linestyle','-.','linewidth',2);
    set(gca,'YLim',[0,5.5]);
    set(gca,'YTick',[0:1:5]);
    set(gca,'XLim',[3.4,4.22]);
    xlabel('Voltage (V)','interpreter','tex','FontName','Arial');
    ylabel('\DeltaQ/\DeltaV (Ah/V)','interpreter','tex','FontName','Arial');
    set(gca,'fontsize',16);
    set(gca,'linewidth',2);
    set(gca,'TickLabelInterpreter','tex','FontName','Arial');
    h = text(0.02,0.06,[' Cell #0',num2str(bat)],'FontSize',16,'Interpreter','tex','units','normalized','FontName','Arial');
    grid on
    box on
    
    if bat == 4
        h = legend('Raw','Referenced','Proposed')
        set(h,'Interpreter','tex','FontSize',16,'ItemTokenSize',[15,36],'location','northeast','FontName','Arial');
    end
    
    text(-0.22,1,str(bat+2),'Fontsize',16,'FontName','Arial','units','normalized');
    
end

% 创建 rectangle
annotation('rectangle',...
    [0.133956228956229 0.640833333333333 0.0122937710437709 0.0202847222222222],...
    'LineWidth',1);

% 创建 arrow
annotation('arrow',[0.149457070707071 0.229633838383838],...
    [0.650534722222222 0.704333333333333],'LineWidth',1);


for bat = 2:4
    [val pos] = FindPeak(ica_ref(bat).dat);
    Ref_val = val';
    Ref_pos = volt_ref(bat).dat(pos)';
    [val pos] = FindPeak(ica_this(bat).dat);
    This_val = val';
    This_pos = volt_this(bat).dat(pos);
    err_val = (Ref_val - This_val)./Ref_val*100
    err_pos = (Ref_pos - This_pos)./Ref_pos*100
end

