function flag = discontinuity(n,param)

% Copyright 2012 The MathWorks, Inc.

flag = any(n==0,1);



