function da = forwardprop(dn,n,a,param)
%PURELIN.FORWARDPROP

% Copyright 2012 The MathWorks, Inc.

load gelu
[M,N] = size(n);
tmp = differentiate (gelu,n);
tmp = reshape(tmp,[M,N]);

% tmp = (gelu(n) - gelu(n+1e-8))/(1e-8);

da = bsxfun(@times,dn, tmp);

% da = bsxfun(@times,dn,(n>=0 + 0.05* (n<0)));
