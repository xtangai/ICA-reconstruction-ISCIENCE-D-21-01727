function name = name()

% Copyright 2012 The MathWorks, Inc.

name = 'Leakly Linear Positive';
