function d = da_dn(n,a,param)

% Copyright 2012 The MathWorks, Inc.

% d = double(n >= 0) + double(n<0) * 0.05;

load gelu
[M,N] = size(n);
tmp = differentiate (gelu,n);
tmp = reshape(tmp,[M,N]);

% tmp = (gelu(n) - gelu(n+1e-8))/(1e-8);


d = tmp;