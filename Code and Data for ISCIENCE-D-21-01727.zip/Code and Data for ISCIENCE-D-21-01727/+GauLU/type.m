function t = type

% Copyright 2012 The MathWorks, Inc.

t = 'transfer_fcn';
