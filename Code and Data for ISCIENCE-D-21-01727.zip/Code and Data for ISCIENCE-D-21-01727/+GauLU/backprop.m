function dn = backprop(da,n,a,param)
%PURELIN.BACKPROP

% Copyright 2012 The MathWorks, Inc.

load gelu
[M,N] = size(n);
tmp = differentiate (gelu,n);
tmp = reshape(tmp,[M,N]);

% dn = bsxfun(@times,da,(n>=0 + 0.05*(n<0)));
dn = bsxfun(@times,da,tmp);