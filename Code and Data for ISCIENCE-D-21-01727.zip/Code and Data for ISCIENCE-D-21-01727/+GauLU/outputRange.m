function or = outputRange

% Copyright 2012 The MathWorks, Inc.

or = [-inf inf];
